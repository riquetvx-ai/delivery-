import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { pool } from './db.js';
dotenv.config();
const app = express();
app.use(cors({ origin: process.env.FRONTEND_URL?.split(',') || true }));
app.use(express.json({limit:'1mb'}));

app.get('/api/health', async (_req,res) => {
  try { await pool.query('SELECT 1'); res.json({ok:true, service:'Delivery do Bairro API'}); }
  catch { res.status(503).json({ok:false, error:'Banco de dados indisponível'}); }
});

app.get('/api/restaurants', async (_req,res) => {
  try {
    const { rows } = await pool.query('SELECT * FROM restaurants ORDER BY is_open DESC, name');
    res.json(rows);
  } catch { res.status(500).json({error:'Não foi possível carregar restaurantes'}); }
});

app.get('/api/restaurants/:id/products', async (req,res) => {
  try {
    const { rows } = await pool.query('SELECT * FROM products WHERE restaurant_id=$1 AND available=true ORDER BY name',[req.params.id]);
    res.json(rows);
  } catch { res.status(500).json({error:'Não foi possível carregar o cardápio'}); }
});

app.post('/api/orders', async (req,res) => {
  const { restaurantId, customerName, customerPhone, address, notes='', paymentMethod='cash', items=[] } = req.body || {};
  if (!restaurantId || !customerName || !customerPhone || !address || !Array.isArray(items) || !items.length) {
    return res.status(400).json({error:'Preencha seus dados, endereço e produtos.'});
  }
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const rest = await client.query('SELECT id,delivery_fee FROM restaurants WHERE id=$1 AND is_open=true',[restaurantId]);
    if (!rest.rowCount) throw new Error('Restaurante não encontrado ou fechado.');
    let subtotal=0, verified=[];
    for (const item of items) {
      const q = Math.max(1, Math.min(50, Number(item.quantity)||1));
      const result = await client.query('SELECT id,name,price FROM products WHERE id=$1 AND restaurant_id=$2 AND available=true',[item.productId,restaurantId]);
      if (!result.rowCount) throw new Error('Um produto não está mais disponível.');
      const p=result.rows[0], line=Number(p.price)*q; subtotal+=line;
      verified.push({id:p.id,name:p.name,price:Number(p.price),quantity:q,total:line});
    }
    const fee=Number(rest.rows[0].delivery_fee), total=subtotal+fee;
    const order = await client.query(
      `INSERT INTO orders (restaurant_id,customer_name,customer_phone,delivery_address,notes,payment_method,subtotal,delivery_fee,total)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING id,status,total,created_at`,
      [restaurantId,customerName,customerPhone,address,notes,paymentMethod,subtotal,fee,total]);
    for (const p of verified) await client.query(
      `INSERT INTO order_items (order_id,product_id,product_name,quantity,unit_price,total) VALUES ($1,$2,$3,$4,$5,$6)`,
      [order.rows[0].id,p.id,p.name,p.quantity,p.price,p.total]);
    await client.query('COMMIT');
    res.status(201).json({...order.rows[0],subtotal,deliveryFee:fee,message:'Pedido recebido!'});
  } catch(e) {
    await client.query('ROLLBACK');
    res.status(400).json({error:e.message || 'Não foi possível criar o pedido.'});
  } finally { client.release(); }
});

app.get('/api/orders/:id', async (req,res) => {
  try {
    const order=await pool.query('SELECT id,status,total,created_at FROM orders WHERE id=$1',[req.params.id]);
    if (!order.rowCount) return res.status(404).json({error:'Pedido não encontrado'});
    const items=await pool.query('SELECT product_name,quantity,unit_price,total FROM order_items WHERE order_id=$1',[req.params.id]);
    res.json({...order.rows[0],items:items.rows});
  } catch { res.status(500).json({error:'Erro ao consultar pedido'}); }
});

const port=process.env.PORT || 4000;
app.listen(port,()=>console.log(`Delivery do Bairro API rodando na porta ${port}`));
