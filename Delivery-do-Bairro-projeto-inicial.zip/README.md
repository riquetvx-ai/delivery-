# Delivery do Bairro — projeto inicial

Plataforma de delivery multirrestaurante para Itu/SP.

## O que vem nesta primeira versão
- Aplicação web responsiva e instalável (PWA), preparada para Android, iPhone e navegador.
- API Node.js + Express.
- PostgreSQL com tabelas para restaurantes, categorias, produtos, clientes, pedidos e itens.
- Tela inicial com restaurantes, busca, cardápios e carrinho.
- Fluxo inicial de criação de pedido.
- Estrutura pronta para evoluir com painel de restaurante, entregador, pagamentos e publicação nas lojas.

> Esta é a base funcional/MVP inicial, não uma cópia do iFood. Antes de operar comercialmente, configure autenticação, pagamentos reais, políticas de privacidade, segurança, monitoramento e testes.

## Requisitos
- Node.js 20+
- PostgreSQL 15+
- npm

## 1. Banco de dados
Crie um banco chamado `delivery_bairro` e execute:

```bash
psql -U postgres -d delivery_bairro -f database/schema.sql
```

O script cria tabelas e alguns restaurantes/produtos de demonstração em Itu.

## 2. Backend
```bash
cd backend
cp .env.example .env
```
Edite `DATABASE_URL` com sua conexão PostgreSQL. Depois:
```bash
npm install
npm run dev
```
A API ficará em `http://localhost:4000`. Teste `http://localhost:4000/api/health`.

## 3. Aplicativo web/PWA
Em outro terminal:
```bash
cd frontend
cp .env.example .env
npm install
npm run dev
```
Abra o endereço exibido pelo Vite. Por padrão, o frontend chama `http://localhost:4000`.

## 4. Publicação
- Backend: Render Web Service, Root Directory `backend`, Build `npm install`, Start `npm start`.
- Banco: Render PostgreSQL. Copie a URL interna para `DATABASE_URL`.
- Frontend: Render Static Site, Root Directory `frontend`, Build `npm install && npm run build`, Publish Directory `dist`.
- Configure `VITE_API_URL` com a URL pública do backend + `/api`.

Execute `database/schema.sql` no banco de produção antes de abrir o serviço.

## 5. Próximas etapas recomendadas
1. Login seguro para cliente, restaurante, entregador e administrador.
2. Painel de gestão de restaurantes e produtos.
3. Aceite de pedidos e atualização de status em tempo real.
4. Integração Pix/cartão por provedor de pagamentos (credenciais da própria empresa).
5. App nativo Android/iOS com Expo/React Native ou empacotamento controlado da PWA.
6. Termos, privacidade, LGPD, política de cancelamento e suporte.

## Observações
- Não coloque senhas ou chaves secretas no frontend.
- Nunca use a URL pública do PostgreSQL no código do navegador.
- Os dados incluídos são fictícios e servem apenas para demonstração.
